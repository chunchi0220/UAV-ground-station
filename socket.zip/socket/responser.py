import os
import socket
import struct
import time,datetime,numbers
import threading
from unittest import result
import re


s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
"""
global message,message_end,drone_status
message = ' '
message_end = ' '
drone_status = ""

statusKeyWithSubkeys = [
    'SYS_STATUS-voltage_battery'
    ,'GPS_RAW_INT-satellites_visible'
    ,'GPS_RAW_INT-fix_type'
    ,'GPS_RAW_INT-lat'
    ,'GPS_RAW_INT-lon'
    ,'EKF_STATUS_REPORT-compass_variance'           # 10
    ,'GLOBAL_POSITION_INT-alt'
    ,'GLOBAL_POSITION_INT-relative_alt'             # 20
    ,'HEARTBEAT-custom_mode'                        #5 loit, guide, stabilize etc.
    ,'EKF_STATUS_REPORT-flags'
    ,'GLOBAL_POSITION_INT-hdg'                      #yaw
]

def get_status(entry,subKey,status):
    entry += ' {'
    tempSubkey = subKey
    tempSubkey += ' : '
    beginIdx = status.find(entry) + len(entry) - 1
    endIdx = status.find('}',status.find(entry)) + 1
    jsonStr = status[beginIdx : endIdx]
    beginIdx = jsonStr.find(tempSubkey) + len(tempSubkey)
    endIdx = jsonStr.find(',', jsonStr.find(tempSubkey))
    value = ''
    if isinstance(endIdx, numbers.Number):
        value = jsonStr[beginIdx : endIdx]
    else:
        endIdx = jsonStr.find('}', jsonStr.find(tempSubkey))
        value = jsonStr[beginIdx : endIdx]
    return value
"""

def get_status2(status):
    match = re.search(r'SYS_STATUS {.*?voltage_battery : (\d+).*?}', status)
    match2 = re.search(r'HEARTBEAT {.*?custom_mode : (\d+).*?}', status)
    if match:
        # print(match.group(0))
        voltage_battery_value = match.group(1)
        #return voltage_battery_value
        #print(f'Voltage Battery: {voltage_battery_value}')
    else:
        voltage_battery_value = ""
        #return ""
        #print('未找到 voltage_battery 值')
    if match2:
        # print(match.group(0))
        mode = match2.group(1)
        #return voltage_battery_value
        #print(f'Voltage Battery: {voltage_battery_value}')
    else:
        mode = ""
        #return ""
        #print('未找到 voltage_battery 值')
    return voltage_battery_value + ',' + mode

def response():
    status_path = r"/home/mmnlab/status.txt"
    result = ""
    while(True):
        try:
            if os.path.isfile(status_path):
                file = open(status_path, "r")
                status = file.read()
                file.close()
                if status != "":
                        result += get_status2(status)
                s.sendto(result.encode(),("192.168.240.3",18888))
                result = ""
                status = ""
                time.sleep(0.5)
        except Exception as e:
            print(e)
            time.sleep(0.5)
                


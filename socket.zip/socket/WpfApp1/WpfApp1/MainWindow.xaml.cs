﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;
using System.Diagnostics;
using System.Security.Policy;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void udp_server()
        {
            string[] _droneStatusArray = { "-1" };
            IPEndPoint IPEnd = new IPEndPoint(IPAddress.Any, 18888); //定義好伺服器port
            Socket Server = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp); //傳輸模式為UDP
            Server.Bind(IPEnd); //綁定ip和port

            IPEndPoint sender = new IPEndPoint(IPAddress.Any, 0); //定義空位址 給接收的存放(唯讀)
            EndPoint Remote = (EndPoint)sender; //宣告可以存放IP位址的用 EndPoint
            byte[] getdata = new byte[1024]; //要接收的封包大小

            ///////////////////server////////////////


            while (true)
            {
                int recv = Server.ReceiveFrom(getdata, ref Remote); //把接收的封包放進getdata且傳回大小存入recv , ReceiveFrom(收到的資料,來自哪個IP放進Remote) 不能放IPEndPoint 因為唯獨
                string input = Encoding.UTF8.GetString(getdata, 0, recv); //把接收的byte資料轉回string型態
                string _dataResult;
                _droneStatusArray = input.Split(',');
                if (_droneStatusArray.Length > 1)
                {
                    try
                    {
                        Trace.WriteLine("客戶來自 " + "[" + Remote.ToString() + "] : " + input); //將收到的顯示
                        _dataResult = "Battery : " + _droneStatusArray[0] + "V" + Environment.NewLine + "Mode : " + _droneStatusArray[1];
                        this.Dispatcher.Invoke((Action)(() =>
                        {
                            DRONE_STATUS.Content = "Drone Status:" + Environment.NewLine + _dataResult;
                        }));
                    }
                    catch (Exception)
                    {

                        throw;
                    }
                }
                Thread.Sleep(10);
            }
        }
        public void command_send(string commaod)
        {
            Socket targetDrone = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp); //定義發送的格式及有效區域
            try
            {
                targetDrone.EnableBroadcast = true;
                targetDrone.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.Broadcast, true);


                string ipStr = "192.168.240.154";

                IPEndPoint remoteIP = new IPEndPoint(IPAddress.Parse(ipStr), Convert.ToInt32("14551"));
                commaod = commaod.Replace(" ", "");
                if (commaod.Length % 2 == 1)
                {
                    commaod = "0" + commaod;
                }
                byte[] pushdata = new byte[commaod.Length / 2];
                string hex;
                int j = 0;
                for (int i = 0; i < (commaod.Length / 2); i++)
                {
                    hex = commaod.Substring(j, 2);
                    pushdata[i] = Convert.ToByte(hex, 16);
                    j += 2;
                }
                targetDrone.SendTo(pushdata, remoteIP);
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string arm_cmd, mode_cmd;
            mode_cmd = "fd 06 00 00 2d ff be 0b 00 00 02 00 00 00 01 01 da 46";
            arm_cmd = "fe 21 00 fc 01 4c 00 00 80 3f 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 90 01 01 01 01 89 f4";
            command_send(mode_cmd);
            Thread.Sleep(10);
            command_send(mode_cmd);
            Thread.Sleep(100);
            command_send(arm_cmd);
            Thread.Sleep(1000);
            command_send(arm_cmd);
        }

        private void STABILIZE_Click(object sender, RoutedEventArgs e)
        {
            string mode_cmd;
            mode_cmd = "fd 06 00 00 2d ff be 0b 00 00 00 00 00 00 01 01 61 71";
            command_send(mode_cmd);
            Thread.Sleep(10);
            command_send(mode_cmd);
        }

        private void ALT_HOLD_Click(object sender, RoutedEventArgs e)
        {
            string mode_cmd;
            mode_cmd = "fd 06 00 00 2d ff be 0b 00 00 02 00 00 00 01 01 da 46";
            command_send(mode_cmd);
            Thread.Sleep(10);
            command_send(mode_cmd);
        }

        private void GUIDED_Click(object sender, RoutedEventArgs e)
        {
            string mode_cmd;
            mode_cmd = "fd 06 00 00 2d ff be 0b 00 00 04 00 00 00 01 01 17 1e";
            command_send(mode_cmd);
            Thread.Sleep(10);
            command_send(mode_cmd);
        }

        private void LOITER_Click(object sender, RoutedEventArgs e)
        {
            string mode_cmd;
            mode_cmd = "fd 06 00 00 2d ff be 0b 00 00 05 00 00 00 01 01 c2 81";
            command_send(mode_cmd);
            Thread.Sleep(10);
            command_send(mode_cmd);
        }

        private void RTL_Click(object sender, RoutedEventArgs e)
        {
            string mode_cmd;
            mode_cmd = "fd 06 00 00 2d ff be 0b 00 00 06 00 00 00 01 01 ac 29";
            command_send(mode_cmd);
            Thread.Sleep(10);
            command_send(mode_cmd);
        }

        private void LAND_Click(object sender, RoutedEventArgs e)
        {
            string mode_cmd;
            mode_cmd = "fd 06 00 00 2d ff be 0b 00 00 09 00 00 00 01 01 58 30";
            command_send(mode_cmd);
            Thread.Sleep(10);
            command_send(mode_cmd);
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Thread server_thread = new Thread(udp_server);
            server_thread.Start();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }
    }
}
